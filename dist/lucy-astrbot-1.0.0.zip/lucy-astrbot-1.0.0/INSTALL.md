# 露西 × AstrBot 发行整合包 v1.0.0

> 露西·瓦伦汀（PIM-001）**以她的本音说话**：QQ 里先到一条日语语音，再到一段中文文字。
> 人格用的是完整版 SKILL（含导演核对），配音走你自己训练的 GPT-SoVITS v5turbo 权重。

---

## 一、包里有什么

| 文件 | 作用 |
|---|---|
| `install-lucy-astrbot.cmd` | **双击就能装**（自动找 Python） |
| `install.py` | 安装器本体；也用来回滚（`--uninstall`） |
| `uninstall-lucy-astrbot.cmd` | 双击回滚 |
| `astrbot-plugin-lucy-voice/` | 插件源码（拷进 `data/plugins/` 即可） |
| `astrbot-plugin-lucy-voice-1.0.0.zip` | 同一个插件的 zip，安装器用它走 WebUI 热装 |
| `tools/setup_astrbot_persona.py` | 把「露西」写进 AstrBot 人格并设为默认 |
| `demo/japanese_sample.wav` | 试听：这就是装完后的声音 |
| `VERSION.txt` / `SHA256SUMS.txt` | 版本与校验 |

---

## 二、先准备三样东西

1. **AstrBot ≥ 4.5**（桌面端或源码都行），并且至少启动过一次（要看到 `~/.astrbot/data/cmd_config.json`）
2. **GPT-SoVITS v5turbo 推理环境**（含 `api_v2.py`）
3. **露西的三件套权重**

   | 角色 | 文件 |
   |---|---|
   | 底模 | `GPT_SoVITS/pretrained_models/gsv-v5-pretrained/s2Gv5turbo.pth`（整合包自带） |
   | 音色 LoRA | `lucy_v1_v5turbo_e8_s14528_l8.pth` |
   | GPT(s1) | `lucy_v1_v5turbo-e10.ckpt` |

   > 权重**不在包里**（200 MB+）。把上面两个文件放到任意位置，安装时填绝对路径即可。
   > 别把 LoRA 写进 yaml 的 `vits_weights_path`——插件会自己生成只含底模的 yaml。

---

## 三、安装（两种都行）

### A. 双击安装（推荐）

双击 `install-lucy-astrbot.cmd` → 按提示走。AstrBot 正在运行时它会问 WebUI 密码，
用来**热装插件 + 写人格**，装完不用重启。

### B. 命令行（可控参数）

```powershell
python install.py ^
  --gpt-weights   "D:\weights\lucy_v1_v5turbo-e10.ckpt" ^
  --sovits-weights "D:\weights\lucy_v1_v5turbo_e8_s14528_l8.pth" ^
  --gsv-root      "D:\GPT-SoVITS-v5" ^
  --password      你的WebUI密码
```

| 参数 | 说明 |
|---|---|
| `--gpt-weights` | GPT(s1) 权重绝对路径 |
| `--sovits-weights` | SoVITS LoRA 绝对路径 |
| `--gsv-root` | GPT-SoVITS 根目录；填了会自动打开 `auto_start`（9880 没起来时插件自己拉） |
| `--api-base` | api_v2 地址，默认 `http://127.0.0.1:9880` |
| `--data` | AstrBot 数据目录，默认 `%USERPROFILE%\.astrbot\data` |
| `--password` | WebUI 密码（热装 + 写人格） |
| `--no-persona` | 不写 AstrBot 人格（插件会自己注入完整版） |
| `--force-config` | 用默认值覆盖插件配置（会丢掉你改过的项） |
| `--dry-run` | 只打印计划 |
| `--uninstall` | 回滚：删插件、默认人格还原为 `default` |

安装器做的事：

1. 找到 AstrBot 数据目录（`cmd_config.json` 所在的 `data`）
2. 合并插件配置（**保留你填过的项**，只补缺的和这次传的参数）
3. 插件：AstrBot 在跑就走 WebUI 热装（自动加载），否则直接拷目录
4. 人格：写 `lucy`（完整版 SKILL + 导演本 + 两段定调对白 + 出错台词），设为默认
5. 自检：插件是否激活、权重文件是否存在、9880 是否在线

---

## 四、装完怎么用

在 QQ 里发一句「我回来了」：

```
🔊「……お帰りなさいませ、マスター。ご飯はまだ温かいです。」   ← 先到：日语语音
……主人回来了。饭还温着。                                    ← 后到：中文文字
```

| 命令 | 作用 |
|---|---|
| `/露西` | 状态（人格/语音/情绪、推理服务是否在线） |
| `/露西 静音` / `/露西 出声` | 只关/开语音 |
| `/露西 开` / `/露西 关` | 人格 + 语音一起开关 |
| `/露西 念 おかえりなさい` | 立刻念一句（中日都行） |
| `/露西 情绪 温柔` | `std/calm/happy/excited/soft/quiet/shy` |
| `/露西 重启` | 重启推理服务 |

---

## 五、验证装对了

1. **插件**：WebUI → 插件管理，能看到「露西语音（Lucy Voice）」且已激活
2. **人格**：WebUI → 人格，能看到 `lucy`，且默认人格是它
3. **日志**：`~/.astrbot/logs/backend.log` 里应有
   - `[露西语音] 人格来自 AstrBot 人格配置，插件只注入语音协议`
   - 每轮回复前 `[露西语音] 合成 xx 字 [ja] '……'`
4. **声音**：`demo/japanese_sample.wav` 就是她该有的音色

---

## 六、排错

| 现象 | 处理 |
|---|---|
| 只有文字没有语音 | 9880 没起来 → 看 `data/temp/lucy_voice/lucy_tts_api.log`；或加 `--gsv-root` 让插件自己拉 |
| 语音是中文腔 | 模型没按格式写日语稿 → 看日志有没有 `[ja]`；`voice.translate_fallback` 打开时会自动翻译 |
| 声音和文字对不上 | 正常不会：`voice.faithful=true` 会查字数/句数，像摘要就改用翻译稿；真遇到把那一轮日志发出来 |
| 声音不像 / 时长翻倍 | 权重加载错了：确认 yaml 里是**底模**，LoRA 走 `/set_sovits_weights` |
| 语音和文字错位 | 关掉 AstrBot 的流式回复 |
| 长回复变图片 | `reply.force_text` 保持打开（默认已开） |
| QQ 里语音发不出 | `qq_official` 机器人需要「语音消息」权限；换 NapCat(aiocqhttp) 最稳 |
| 每轮 token 高 | 人格约 1.6 万字符/轮，这是「完整版」的代价；可关 `persona.inject` 并改用 AstrBot 人格 |

---

## 七、回滚

```powershell
python install.py --uninstall            # 删插件 + 默认人格还原为 default
python install.py --uninstall --purge-persona   # 连 lucy 人格一起删
```

配置文件（`data/config/astrbot_plugin_lucy_voice_config.json`）默认保留，方便重装；
它的开关在 WebUI → 插件管理 → 露西语音里也能一键关掉，不必卸载。

---

## 八、许可

插件代码随包自用；《露西 -她所期望的一切-》的角色、台词与配音版权归 **M-Vizlab**，
这里只做个人本地的角色扮演与音色克隆，请勿用于商业发布或二次分发。
